
namespace TownOfUs.CrewmateRoles.MediumMod
{
    public enum DeadRevealed
    {
        Oldest = 0,
        Newest,
        All
    }
}