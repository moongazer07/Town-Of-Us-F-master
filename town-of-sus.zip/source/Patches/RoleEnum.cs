namespace TownOfUs
{
    public enum RoleEnum
    {
        Sheriff,
        Jester,
        Engineer,
        Mayor,
        Swapper,
        Investigator,
        TimeLord,
        Medic,
        Seer,
        Executioner,
        Spy,
        Snitch,
        Arsonist,
        Altruist,
        Phantom,
        Vigilante,
        Haunter,
        Veteran,
        Amnesiac,
        Juggernaut,
        Tracker,
        Transporter,
        Medium,
        Trapper,
        Survivor,
        GuardianAngel,
        Mystic,
        Plaguebearer,
        Pestilence,
        Werewolf,
        Detective,

        Miner,
        Swooper,
        Morphling,
        Janitor,
        Undertaker,
        Underdog,
        Grenadier,
        Poisoner,
        Traitor,
        Blackmailer,


        Glitch,

        Crewmate,
        Impostor,
        None
    }

    public enum ModifierEnum
    {
        Lover,
        Torch,
        Diseased,
        Flash,
        Tiebreaker,
        Giant,
        ButtonBarry,
        Bait,
        Sleuth,
        Blind
    }

    public enum AbilityEnum
    {
        Assassin
    }
}
