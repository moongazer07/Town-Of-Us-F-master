﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TownOfUs.Patches
{
    public class ClientOptions
    {
        public static bool HorseEnabled = false;
    }
}
